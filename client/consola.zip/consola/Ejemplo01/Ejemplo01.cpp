//Consola Ejemplo de Uso
/*************************************************************
CONSOLA.H
LIBRER�A PARA AUMENTAR LA EXTENSI�N DE CONIO.H EN VISUAL C++
(Da soporte a funciones como gotoxy, clrscr, etc.)

Antonio A.
http://ayudacpp.tripod.com.mx/
ayudacpp@tutopia.com
M�xico, D.F.

**************************************************************/

//////////////////////////////////////////////////////////////
//Ejemplo01 con "iostream.h" usando cout<<


#include <ostream.h>
#include <conio.h>

#include "Consola.h" //archivo de cabecera para la librer�a


void titulo();


int main()
{
 int i;

 titulo();

 gotoxy(30,12);
 cout<<"Tipo de cursor:"<<endl;

 gotoxy(30,14);
 _setcursortype(_NORMALCURSOR);
 cout<<"CURSOR NORMAL ->  "<<flush;
 getch(); 

 gotoxy(30,16);
  _setcursortype(_SOLIDCURSOR);
 cout<<"CURSOR SOLIDO ->  "<<flush;
 getch();

 gotoxy(30,18);
 _setcursortype(_NOCURSOR);
 cout<<"CURSOR OCULTO ->  "<<flush;
 getch();


 gotoxy(1,25);
 _setcursortype(_NORMALCURSOR);
 cout<<"Presione una tecla para continuar..."<<flush;
 getch();
 


 //cambiando color de fondo
 for(i=0;i<16;i++)
	{
	textcolor(16-i-1);
	textbackground(i);	
	clrscr();

	titulo();

	gotoxy(26,15);
	cout<<"Color de fondo: "<<i<<flush;	
	gotoxy(26,17);
	cout<<"Color de texto: "<<16-i-1<<flush;
	delay(1000);//pausa de mil milisegundos (un segundo)
	}


 //colocando de nuevo la pantalla negra y texto gris claro
 textbackground(BLACK);//fondo negro (0 � BLACK)
 textcolor(LIGHTGRAY);//color de texto gris (7 � LIGHTGRAY)
 clrscr();

 titulo();


 for(i=0;i<16;i++)
	{
	textcolor(16-i-1);
	textbackground(i);

	gotoxy(30,i+5);
	cout<<"fondo ="<<i<<"  texto ="<<16-i-1<<flush;
	}


 gotoxy(1,25);
 cout<<"FIN "<<flush;
 getch();


 //colocando de nuevo la pantalla negra y texto gris claro
 textbackground(BLACK);//fondo negro (0 � BLACK)
 textcolor(LIGHTGRAY);//color de texto gris (7 � LIGHTGRAY)
 clrscr();

 return 0;
}

void titulo()
{
 gotoxy(22,1);
 cout<<"FUNCIONES DE CONSOLA PARA VISUAL C++"<<endl;
 
 gotoxy(1,5);
 cout<<"Ejemplo usando:\n  gotoxy\n  clrscr\n  textcolor"
	 "\n  textbackground\n  delay\n  _setcursortype"<<endl;

 gotoxy(49,25);
 cout<<"http://ayudacpp.tripod.com.mx/"<<flush;

}




