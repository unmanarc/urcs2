//Consola Ejemplo de Uso
/*************************************************************
CONSOLA.H
LIBRER�A PARA AUMENTAR LA EXTENSI�N DE CONIO.H EN VISUAL C++
(Da soporte a funciones como gotoxy, clrscr, etc.)

Antonio A.
http://ayudacpp.tripod.com.mx/
ayudacpp@tutopia.com
M�xico, D.F.

**************************************************************/


//////////////////////////////////////////////////////////////
//Ejemplo02 con "stdio.h" usando printf o cprintf

#include <stdio.h>
#include <conio.h>

#include "Consola.h" //archivo de cabecera para la librer�a



void titulo();


int main()
{
 int i;

 titulo();

 gotoxy(30,12);
 printf("Tipo de cursor:");

 gotoxy(30,14);
 _setcursortype(_NORMALCURSOR);
 printf("CURSOR NORMAL ->  ");
 getch(); 

 gotoxy(30,16);
  _setcursortype(_SOLIDCURSOR);
 printf("CURSOR SOLIDO ->  ");
 getch();

 gotoxy(30,18);
 _setcursortype(_NOCURSOR);
 printf("CURSOR OCULTO ->  ");
 getch();


 gotoxy(1,25);
 _setcursortype(_NORMALCURSOR);
 printf("Presione una tecla para continuar...");
 getch();
 


 //cambiando color de fondo
 for(i=0;i<16;i++)
	{
	textcolor(16-i-1);
	textbackground(i);	
	clrscr();

	titulo();

	gotoxy(26,15);
	printf("Color de fondo: %d",i);
	gotoxy(26,17);
	printf("Color de texto: %d",16-i-1);
	delay(1000);//pausa de mil milisegundos (un segundo)
	}


 //colocando de nuevo la pantalla negra y texto gris claro
 textbackground(BLACK);//fondo negro (0 � BLACK)
 textcolor(LIGHTGRAY);//color de texto gris (7 � LIGHTGRAY)
 clrscr();

 titulo();


 for(i=0;i<16;i++)
	{
	textcolor(16-i-1);
	textbackground(i);

	gotoxy(30,i+5);
	printf("fondo = %2d  texto = %2d",i,16-i-1);
	}


 gotoxy(1,25);
 printf("FIN ");
 getch();


 //colocando de nuevo la pantalla negra y texto gris claro
 textbackground(BLACK);//fondo negro (0 � BLACK)
 textcolor(LIGHTGRAY);//color de texto gris (7 � LIGHTGRAY)
 clrscr();

 return 0;
}

void titulo()
{
 gotoxy(22,1);
 printf("FUNCIONES DE CONSOLA PARA VISUAL C++");
 
 gotoxy(1,5);
 printf("Ejemplo usando:\n  gotoxy\n  clrscr\n  textcolor"
	 "\n  textbackground\n  delay\n  _setcursortype");

 gotoxy(49,25);
 printf("http://ayudacpp.tripod.com.mx/");
}


